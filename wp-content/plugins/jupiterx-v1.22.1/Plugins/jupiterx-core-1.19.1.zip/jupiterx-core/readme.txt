=== Jupiter X Core ===
Contributors: artbees
Tags: jupiter, jupiterx
Requires at least: 4.7
Tested up to: 5.4
Requires PHP: 5.6
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Core functionalities for Jupiter X theme.

== Description ==

Core functionalities for Jupiter X theme.

== Installation ==

1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0.0 =
* Initial release
