<?php
/**
 * Features list start template
 */
?>
<div class="jet-portfolio__list"><?php
	if ( 'justify' === $this->get_settings_for_display( 'layout_type' ) ) {?>
		<div class="grid-sizer"></div><?php } ?>
