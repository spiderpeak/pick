<?php
/**
 * Cart Empty Message Template
 */

do_action( 'woocommerce_cart_is_empty' );
