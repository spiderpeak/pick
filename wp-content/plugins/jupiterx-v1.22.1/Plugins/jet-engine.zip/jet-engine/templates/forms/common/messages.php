<div class="<?php echo $class; ?>">
	<?php echo $message_content; ?>
</div>